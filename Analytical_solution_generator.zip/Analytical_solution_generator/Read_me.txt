Analytical_params: aquifer parameters for the analytical solution. 
		   a is distance to recharge point (meters), which is half the valley width
		   b is aquife thickness in meters 
		   c is distance to valley boundary (meters), which is 2*a
	           Sy is specific yeild (dimensionless)
		   K is hydraulic conductivity in meters/day 
	           D is the resulting hydraulic diffusivity 

Analytical_return_flow_generator: script that uses the Analytical_params to generate superposed return flows resulting from 
				  three annual recharge maginitudes that are presented in the paper (10, 20, and 30 cm per year)
			          whose normalized annual pattern is defined by the "Modflow_stress_periods" data 

Modflow_stress_periods: First two columns define the stress periods for simulations with units of days. 
		        First column is the start of the stress period
                        Second is the end of the stress period
			Third column is the irrigation rate for the stress periods in units of m/d
			Fourth column is the stream stage for the stress periods in units of m

Superposed_return_flows: The output of the python script with rows as aquifer parameters as defined in Analytical_params.csv
		         There are 3 rows for each parameter scenario corresponding to 10, 20, and 30 cm/year of recharge 
			 Columns are monthly return flow volumes in m^3. 
	          