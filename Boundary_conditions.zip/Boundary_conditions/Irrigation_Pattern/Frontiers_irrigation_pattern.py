import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

os.chdir("C:\\Users\XXXXXX\Documents\Frontiers_Paper\Boundary_Conditions\Irrigation_Pattern") # change absolute path to 'Irrigation_Pattern' folder
iwr = pd.read_csv("Colorado_iwr_formatted_monthly.csv")

# monthly average for each user 
avg_monthly_irrigation = np.zeros([12,np.size(iwr.iloc[0,:])-1])
avg_monthly_irrigation = pd.DataFrame(avg_monthly_irrigation, columns = iwr.columns[1:])
avg_monthly_irrigation.Month = np.arange(12)+1

for j in range(12):
    data = iwr.where(iwr.Month == j+1)
    for i in range(np.size(iwr.iloc[0,:])-2):
        total = np.sum(data.iloc[:,i+2])
        avg_monthly_irrigation.iloc[j,i+1] = total/105

avg_monthly_norm = avg_monthly_irrigation.copy()
annual_irrigation = np.sum(avg_monthly_irrigation.iloc[:,1:])

for i in range(np.size(annual_irrigation)):
    avg_monthly_norm.iloc[:,i+1] = np.divide(avg_monthly_norm.iloc[:,i+1],annual_irrigation[i])
    
check = np.sum(avg_monthly_norm)
        
summary_stats = np.zeros([12,9])
summary_stats = pd.DataFrame(summary_stats, columns = ['month','count','Mean','std',
                'min','25%','50%','75%', 'max'])
summary_stats.month = np.arange(12)+1

for i in range(12):
    summary_stats.iloc[i,1:] = avg_monthly_norm.iloc[i,1:].describe()
    
months = np.arange(12)+1               
plt.plot(months, summary_stats.Mean[:])
plt.xlabel('month')
plt.ylabel('Normalized Irrigation [-]')       

normalized_irrigation_pattern = pd.DataFrame(summary_stats.Mean)
normalized_irrigation_pattern.to_csv('normalized_irrigation_pattern.csv', header = False)