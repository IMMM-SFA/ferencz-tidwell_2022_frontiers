import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

os.chdir("C:\\Users\XXXXXX\Documents\Frontiers_Paper\Boundary_Conditions\River_Stage_Pattern") # Change absolute path to 'River_Stage_Pattern' folder
ids = np.array(['09081000','09073300','09064600','09059500','09058000','09041090',
       '09024000','09081600','09095500','09010500','09105000','09238900',
       '09242500','09247600','07081200','09112200','07091200','09113980',
       '09143500','09144250','09147500','09106150','09342500','09063000'
       ])

headers = ['month','09081000','09073300','09064600','09059500','09058000','09041090',
       '09024000','09081600','09095500','09010500','09105000','09238900',
       '09242500','09247600','07081200','09112200','07091200','09113980',
       '09143500','09144250','09147500','09106150','09342500','09063000']

months = np.arange(12)+1
stage_df = pd.DataFrame(np.zeros([12,np.size(ids)+1]), columns = headers)
stage_df.month = months

# 20 yr daily discharge data records and associated rating curves for each gauge
# calculates average monthly stage for each gauge 
for i in range(24):
    rating_curve = pd.read_csv(ids[i] + '_rating_curve.csv')
    gauge_ts = pd.read_csv(ids[i] + '_Q.csv')
    reg = np.polyfit(rating_curve.Q_cfs,rating_curve.stage,4)
    p = np.poly1d(reg)
    reg_stage = p(rating_curve.Q_cfs)
    gauge_ts.stage = p(gauge_ts.Q_cfs)
    
    for j in range(12):
        data = gauge_ts.where(gauge_ts.month == j+1)
        monthly_avg = data.stage.mean()
        stage_df.iloc[j,i+1] = monthly_avg
    
    # plots - uncomment if you want plots of each gauge 

    # fig, axs = plt.subplots(1, 2)
    # fig.set_size_inches(8,4)
    # axs[0].plot(rating_curve.Q_cfs,rating_curve.stage, color = 'blue') 
    # axs[0].plot(rating_curve.Q_cfs,reg_stage, color = 'red')
    # axs[0].set(xlabel = 'Q [cfs]', ylabel ='Stage [ft]')

    # axs[1].plot(gauge_ts.month, gauge_ts.stage)
    # axs[1].set(xlabel = 'Time [month]', ylabel ='Stage')
    
    # fig_name = ids[i] + '_fig'
    # plt.savefig(fig_name, dpi=300, facecolor='w', edgecolor='w',
    #             orientation='portrait')

# normalize stage data 
stage_df_normalized = stage_df.copy()
for i in range(24):
    stage_df_normalized.iloc[:,i+1] = stage_df_normalized.iloc[:,i+1] - (np.amin(stage_df_normalized.iloc[:,i+1]))
    stage_df_normalized.iloc[:,i+1] = np.divide(stage_df_normalized.iloc[:,i+1],np.amax(stage_df_normalized.iloc[:,i+1]))

normalized_avg_m = stage_df_normalized.iloc[:,1:].mean(axis = 1)
normalized_avg_m = np.divide(normalized_avg_m,np.amax(normalized_avg_m))

for i in range(24):
    plt.plot(months,np.divide(stage_df_normalized.iloc[:,i+1],np.amax(stage_df_normalized.iloc[:,i+1])), color = 'gray')
    
plt.plot(months,normalized_avg_m,color = 'red')
plt.xlabel('Month')
plt.ylabel('Normalized stage fluctuation [-]')

normalized_stage_pattern = pd.DataFrame(normalized_avg_m)
normalized_stage_pattern.to_csv('normalized_stage_pattern.csv', header = False)