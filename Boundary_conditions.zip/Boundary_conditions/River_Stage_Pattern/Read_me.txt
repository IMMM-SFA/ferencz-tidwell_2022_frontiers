To run stage boundary condition script unzip the CO_gauge_data zip file and put contents into Hydrograph folder. 
The script uses 20-year records from 24 stream gauges in Colorado to calculate a normalized monthly stage pattern 
that is used for the river stage boundary of the Modflow models. 