# -*- coding: utf-8 -*-
"""
Created on Tue Sep 14 16:29:58 2021

@author: sbferen
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

os.chdir("C:\\Users\xxxxx\Documents\Frontiers_Paper\Boundary_Conditions\Recharge_Pattern") # change absolute path to 'Recharge_Pattern" folder
swb_data = pd.read_csv("800m_4km_10pc_runoff_monthly_SUMS_m3.csv")

#### SWB analysis 

metric = 'RECHARGE'
param = swb_data.where(swb_data.Param == metric)
param = param.dropna()

months= np.arange(12)+1
monthly_data = np.zeros([12,35])
monthly_data[:,0] = months

for i in range(12):
    data = param.where(param.month == i+1)
    data = data.dropna()
    monthly_data[i,1:] = data.vol_m3
    
monthly_data = pd.DataFrame(monthly_data)
summary_stats = np.zeros([12,9])
summary_stats = pd.DataFrame(summary_stats, columns = ['month','count','mean','std',
                'min','25%','50%','75%', 'max'])
summary_stats.month = np.arange(12)+1

# Absolute reacharge 

for i in range(12):
    summary_stats.iloc[i,1:] = monthly_data.iloc[i,1:].describe()

label = ['25%','50%','75%']

plt.plot(months, summary_stats.iloc[:,5]/2.9E+11)
plt.plot(months, summary_stats.iloc[:,6]/2.9E+11)
plt.plot(months, summary_stats.iloc[:,7]/2.9E+11)
plt.legend(labels = label, title = 'percentile')
plt.xlabel('month')
plt.ylabel(metric +' [m^3]')

# Normalized recharge
for i in range(12):
    summary_stats.iloc[i,1:] = monthly_data.iloc[i,1:].describe()

label = ['25%','50%','75%']

plt.plot(months, (summary_stats.iloc[:,5]/2.9E+11)/np.sum(summary_stats.iloc[:,5]/2.9E+11))
plt.plot(months, (summary_stats.iloc[:,6]/2.9E+11)/np.sum(summary_stats.iloc[:,6]/2.9E+11))
plt.plot(months, (summary_stats.iloc[:,7]/2.9E+11)/np.sum(summary_stats.iloc[:,7]/2.9E+11))
plt.legend(labels = label, title = 'percentile')
plt.xlabel('month')
plt.ylabel('Normalized' + metric +' [-]')

median_normalized_recharge = pd.DataFrame(summary_stats.iloc[:,6]/2.9E+11 \
    /np.sum(summary_stats.iloc[:,6]/2.9E+11))
median_normalized_recharge.to_csv('normalized_recharge_signal.csv', header = False)





