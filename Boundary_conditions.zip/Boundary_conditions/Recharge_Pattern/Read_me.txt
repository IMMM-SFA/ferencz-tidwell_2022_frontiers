Citation:
Tillman, F.D., 2017, Soil-Water Balance Groundwater Recharge Model Results for the Upper Colorado River Basin 
(ver. 2.0, April 2017): U.S. Geological Survey data release, http://dx.doi.org/10.5066/F7ST7MX7.

Data link: https://www.sciencebase.gov/catalog/item/58ee3dc7e4b0eed1ab8cf13d

