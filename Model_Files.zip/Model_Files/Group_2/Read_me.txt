Group_2_params: Parameter settings for Group 2 simulations. Rows 2-145 corresponds to a transient MODFLOW simulation whose results 
                in the same order are in Group_2_return_flow_results. Rows 146-289 correspond to baseline simulations which are 
                the same parameters as in Rows 2-145 but without any irrigation recharge. The baseline results are in Group_2_baseline_results.
Group_2_reset: Reset modflow models to baseline parameters (b = 20 m, Sy = 0.3, K = 3, Stage amplitude of 1 m, and total 
               irrigation recharge of 0.3 m/yr))
Group_2_baseline_results: daily groundwater flux in m^3/d for each return flow scenario (rows 146-289 in the params csv). Columns are days, 
                rows are scenarios, units are m^3/d. The plotting script aggregates the daily results into m^3/month. 
Group_2_return_flow_results: daily groundwater flux in m^3/d for each baseline scenario (rows 2-145 in the params csv).Columns are days, 
                rows are scenarios, units are m^3/d. The plotting script aggregates the daily results into m^3/month. 
Superposed_return_flows: Analytical return flows for comparison to model results. Columns are months, rows are combinations of 
                parameters as defined in the 'Analytical Params' csv, and units are m^3/month.


             