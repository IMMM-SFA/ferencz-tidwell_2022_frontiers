Group_3_params: Parameter settings for Group 3 simulations. Each row corresponds to a transient MODFLOW simulation and row in the 
		Group_3_return_flow_results.csv. 
Group_3_baseline_params: Parameter settings for Group 3 baseline simulations where there is no irrigation recharge.
Group_3_reset: Reset modflow models to baseline parameters (b = 20 m, Sy = 0.3, K = 3, Stage amplitude of 1 m, and total 
               irrigation recharge of 0.3 m/yr). This is used to reset both the return flow model params and the baseline model params. 
Group_3_baseline_results: daily groundwater flux in m^3/d for each return flow scenario as defined in the Group_3_baseline_params file. 
		Columns are days, rows are scenarios, units are m^3/d. The plotting script aggregates the daily results into m^3/month.
Group_3_return_flow_results: daily groundwater flux in m^3/d for each baseline scenario. Columns are days, rows are scenarios, units 
		are m^3/d. The plotting script aggregates the daily results into m^3/month. 
Superposed_return_flows: Analytical return flows for comparison to model results. Columns are months, rows are combinations of 
                parameters as defined in the 'Analytical Params' csv, and units are m^3/month.


             